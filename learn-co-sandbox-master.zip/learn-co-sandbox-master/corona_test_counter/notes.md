1. flow
2. classes
  2d. class relationships

- user shown last 30 days totals / maybe sum at the bottom
- user asked different options if would like a certain date
- maybe user can select a different state
- ask user if they would like to view more date on covid at worldometers.
- 
classes
- Counter
- CLI
- Scraper