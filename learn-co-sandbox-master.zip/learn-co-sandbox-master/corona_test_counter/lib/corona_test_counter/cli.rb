class CoronaTestCounter::CLI 
  def call 
    puts "Welcome to the Covid Test Counter"
  end
end