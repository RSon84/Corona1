require_relative "./corona_test_counter/version"
require_relative "./corona_test_counter/cli"

module CoronaTestCounter
  class Error < StandardError; end
  # Your code goes here...
end
