echo "This is my readme file" > README.md
echo "This is my readme file"
